import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react';
import { geoMercator, geoPath } from 'd3-geo';
import { feature } from 'topojson-client';
import { estadosTopoJSON, ESTADOS, CENTROIDES_ESTADOS, estado as getEstadoByCve } from '@webrek/mx-geo';
import { Compass } from 'lucide-react';
import { formatPopulation, getRegionInfo } from '../utils/map';

const WIDTH = 960;
const HEIGHT = 640;

export default function MexicoMap({
  selectedState,
  onSelectState,
  zoom,
  setZoom,
  pan,
  setPan,
  showLabels,
  onHoverStateChange
}) {
  const [hoveredCve, setHoveredCve] = useState(null);
  const [tooltip, setTooltip] = useState(null); // { x, y, state }
  const [coords, setCoords] = useState({ lon: -102.5, lat: 23.6 });
  const containerRef = useRef(null);
  const isDragging = useRef(false);
  const startPan = useRef({ x: 0, y: 0 });

  // 1. Proyección geoespacial Mercator sobre las geometrías oficiales de INEGI
  const { paths, boundsMap, centroids } = useMemo(() => {
    const fc = feature(estadosTopoJSON, estadosTopoJSON.objects.estados);
    const projection = geoMercator().fitExtent(
      [
        [36, 36],
        [WIDTH - 36, HEIGHT - 36]
      ],
      fc
    );
    const pathGen = geoPath(projection);

    const pathsMap = {};
    const bMap = {};
    const cMap = {};

    fc.features.forEach((feat) => {
      const cve = feat.properties.cve;
      pathsMap[cve] = pathGen(feat);
      bMap[cve] = pathGen.bounds(feat);
    });

    // Proyectar centroides
    for (const [cve, lonlat] of Object.entries(CENTROIDES_ESTADOS)) {
      const pt = projection(lonlat);
      if (pt) cMap[cve] = pt;
    }

    return { paths: pathsMap, boundsMap: bMap, centroids: cMap };
  }, []);

  // Manejo de zoom con la rueda del ratón
  const handleWheel = useCallback(
    (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
      setZoom((prev) => {
        const next = Math.max(0.8, Math.min(6.0, prev * zoomFactor));
        return next;
      });
    },
    [setZoom]
  );

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  // Arrastre del mapa (Pan)
  const handleMouseDown = (e) => {
    if (e.button !== 0) return; // solo click izquierdo
    isDragging.current = true;
    startPan.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e) => {
    if (isDragging.current) {
      setPan({
        x: e.clientX - startPan.current.x,
        y: e.clientY - startPan.current.y
      });
    }

    // Actualizar coordenadas HUD simuladas según posición en el mapa
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const normX = (e.clientX - rect.left) / rect.width;
      const normY = (e.clientY - rect.top) / rect.height;
      const lon = -118 + normX * 32;
      const lat = 32 - normY * 18;
      setCoords({ lon: lon.toFixed(2), lat: lat.toFixed(2) });
    }

    // Actualizar posición del tooltip si hay hover
    if (tooltip && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setTooltip((prev) =>
        prev
          ? {
              ...prev,
              x: e.clientX - rect.left,
              y: e.clientY - rect.top
            }
          : null
      );
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleStateMouseEnter = (cve, e) => {
    setHoveredCve(cve);
    const st = getEstadoByCve(cve);
    if (st && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setTooltip({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        state: st
      });
      if (onHoverStateChange) onHoverStateChange(st);
    }
  };

  const handleStateMouseLeave = (cve) => {
    if (hoveredCve === cve) {
      setHoveredCve(null);
      setTooltip(null);
      if (onHoverStateChange) onHoverStateChange(null);
    }
  };

  const handleStateClick = (cve) => {
    const st = getEstadoByCve(cve);
    if (st) {
      onSelectState(st);
    }
  };

  return (
    <div
      className="map-viewport"
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => {
        handleMouseUp();
        setTooltip(null);
        setHoveredCve(null);
      }}
      role="region"
      aria-label="Mapa interactivo de la República Mexicana"
    >
      {/* Rosa de los vientos tecnológica */}
      <div className="compass-rose" aria-hidden="true">
        <svg width="72" height="72" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(0,240,255,0.2)" strokeWidth="1" strokeDasharray="2 3" />
          <circle cx="50" cy="50" r="35" fill="none" stroke="rgba(56,189,248,0.15)" strokeWidth="0.8" />
          <line x1="50" y1="5" x2="50" y2="95" stroke="rgba(0,240,255,0.25)" strokeWidth="1" />
          <line x1="5" y1="50" x2="95" y2="50" stroke="rgba(0,240,255,0.25)" strokeWidth="1" />
          <polygon points="50,12 55,45 50,42 45,45" fill="#00f0ff" />
          <polygon points="50,88 55,55 50,58 45,55" fill="#1e3a8a" />
          <polygon points="88,50 55,55 58,50 55,45" fill="#3b82f6" />
          <polygon points="12,50 45,55 42,50 45,45" fill="#3b82f6" />
          <text x="50" y="8" fill="#00f0ff" fontSize="9" fontWeight="bold" textAnchor="middle">N</text>
        </svg>
      </div>

      {/* Coordenadas HUD en vivo */}
      <div className="hud-coordinates">
        <span>LON: {coords.lon}° W</span>
        <span>LAT: {coords.lat}° N</span>
        <span>PROY: MERCATOR (INEGI)</span>
      </div>

      {/* Tooltip flotante interactivo */}
      {tooltip && tooltip.state && (
        <div
          className="map-tooltip-hud"
          style={{ left: tooltip.x, top: tooltip.y }}
          role="tooltip"
        >
          <div className="tooltip-title">
            <span>{tooltip.state.nombre}</span>
            <span className="tooltip-cve">{tooltip.state.iso}</span>
          </div>
          <div className="tooltip-detail">
            Capital: <strong style={{ color: '#ffffff' }}>{tooltip.state.capital}</strong> • Región: {getRegionInfo(tooltip.state.region).name}
          </div>
          <div className="tooltip-detail" style={{ fontSize: '0.7rem', color: 'var(--blue-bright)', marginTop: '2px' }}>
            Población: {formatPopulation(tooltip.state.poblacion)}
          </div>
        </div>
      )}

      {/* Contenedor SVG con transformaciones de Zoom y Pan */}
      <div className="map-svg-container">
        <svg
          viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
          className="map-svg"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            {/* Filtro de resplandor para estado seleccionado */}
            <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#00f0ff" floodOpacity="0.8" />
              <feDropShadow dx="0" dy="0" stdDeviation="1" floodColor="#ffffff" floodOpacity="0.9" />
            </filter>

            {/* Sombra de relieve sutil */}
            <filter id="reliefShadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="2" dy="4" stdDeviation="4" floodColor="#000000" floodOpacity="0.5" />
            </filter>

            {/* Patrón de cuadrícula de paralelos y meridianos */}
            <pattern id="grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 48 0 L 0 0 0 48" fill="none" stroke="rgba(255, 255, 255, 0.015)" strokeWidth="1" />
            </pattern>
          </defs>

          {/* Capa de fondo con cuadrícula */}
          <rect width={WIDTH} height={HEIGHT} fill="url(#grid)" pointerEvents="none" />

          {/* Grupo principal escalado y desplazado */}
          <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
            {/* 1. Dibujar todos los estados no seleccionados primero */}
            {ESTADOS.map((st) => {
              const d = paths[st.cve];
              if (!d) return null;
              const isSelected = selectedState?.cve === st.cve;
              if (isSelected) return null; // se renderiza en la capa superior

              return (
                <path
                  key={st.cve}
                  id={st.iso}
                  data-cve={st.cve}
                  d={d}
                  className="state-path state-normal"
                  tabIndex={0}
                  role="button"
                  aria-label={`${st.nombreCorto}, Capital: ${st.capital}`}
                  onMouseEnter={(e) => handleStateMouseEnter(st.cve, e)}
                  onMouseMove={(e) => handleStateMouseEnter(st.cve, e)}
                  onMouseLeave={() => handleStateMouseLeave(st.cve)}
                  onClick={() => handleStateClick(st.cve)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleStateClick(st.cve);
                    }
                  }}
                />
              );
            })}

            {/* 2. Dibujar el estado seleccionado en la capa superior con glow y elevación */}
            {selectedState && paths[selectedState.cve] && (
              <path
                id={`selected-${selectedState.iso}`}
                data-cve={selectedState.cve}
                d={paths[selectedState.cve]}
                className="state-path state-selected"
                filter="url(#cyanGlow)"
                tabIndex={0}
                role="button"
                aria-label={`Seleccionado: ${selectedState.nombre}`}
                onClick={() => handleStateClick(selectedState.cve)}
              />
            )}

            {/* 3. Etiquetas tipográficas de los estados (opcionales o activables) */}
            {showLabels &&
              ESTADOS.map((st) => {
                const pt = centroids[st.cve];
                if (!pt) return null;
                const isSelected = selectedState?.cve === st.cve;
                return (
                  <text
                    key={`label-${st.cve}`}
                    x={pt[0]}
                    y={pt[1]}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fontSize={isSelected ? 10 : 8}
                    fontWeight={isSelected ? 700 : 500}
                    fill={isSelected ? '#00f0ff' : 'rgba(226, 232, 240, 0.75)'}
                    style={{
                      pointerEvents: 'none',
                      userSelect: 'none',
                      textShadow: '0 1px 4px rgba(0,0,0,0.9)'
                    }}
                  >
                    {st.abreviatura}
                  </text>
                );
              })}
          </g>
        </svg>
      </div>
    </div>
  );
}
