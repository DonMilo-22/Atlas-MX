import React, { useState } from 'react';
import { 
  Compass, 
  MapPin, 
  Users, 
  Maximize2, 
  Clock, 
  Globe, 
  Sparkles, 
  ArrowRight, 
  Utensils, 
  Landmark, 
  Waves, 
  Navigation 
} from 'lucide-react';
import { vecinos, estado as getEstadoByCve } from '@webrek/mx-geo';
import { formatArea, formatPopulation, getRegionInfo } from '../utils/map';
import { TOURISM_DATA } from '../data/states';

export default function StatePanel({ selectedState, onSelectState, onExploreState }) {
  const [activeTab, setActiveTab] = useState('destinos');

  if (!selectedState) {
    return (
      <aside className="atlas-sidebar" aria-label="Información del estado seleccionado">
        <div className="state-empty-view">
          <div className="empty-radar" aria-hidden="true">
            <Compass size={36} color="#00f0ff" />
          </div>
          <h2 className="empty-title">ESTADO SELECCIONADO</h2>
          <p className="empty-desc">
            Selecciona un estado en el mapa o utiliza el buscador superior para explorar su información territorial y turística.
          </p>
        </div>
      </aside>
    );
  }

  const tourism = TOURISM_DATA[selectedState.cve]?.turismo || {
    destinos: ['Centro Histórico', 'Plaza Principal'],
    pueblosMagicos: [],
    arqueologia: [],
    playas: [],
    gastronomia: ['Platillos típicos regionales'],
    clima: 'Clima característico de la región'
  };

  const lema = TOURISM_DATA[selectedState.cve]?.lema;
  const resumen = TOURISM_DATA[selectedState.cve]?.resumen;
  const neighborKeys = vecinos(selectedState.cve) || [];
  const regionInfo = getRegionInfo(selectedState.region);

  return (
    <aside className="atlas-sidebar" aria-label={`Información de ${selectedState.nombre}`}>
      <div className="state-content-view">
        {/* Cabecera del estado seleccionado */}
        <div className="state-header-card">
          <div className="state-header-top">
            <span className="state-iso-pill">{selectedState.iso}</span>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>
              INEGI: {selectedState.cve}
            </span>
          </div>

          <h2 className="state-name-display">{selectedState.nombre}</h2>
          <div className="state-capital-display">
            <MapPin size={14} />
            <span>Capital: {selectedState.capital}</span>
          </div>

          {lema && <div className="state-lema-quote">«{lema}»</div>}
        </div>

        {/* Métricas territoriales y geográficas */}
        <div className="stats-grid">
          <div className="stat-box">
            <div className="stat-label">Región</div>
            <div className="stat-value" style={{ color: regionInfo.color, fontSize: '0.84rem' }}>
              {selectedState.region ? selectedState.region.toUpperCase() : 'FEDERAL'}
            </div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Población (2020)</div>
            <div className="stat-value">{formatPopulation(selectedState.poblacion)}</div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Superficie</div>
            <div className="stat-value">{formatArea(selectedState.superficie)}</div>
          </div>

          <div className="stat-box">
            <div className="stat-label">Huso Horario</div>
            <div className="stat-value" style={{ fontSize: '0.76rem', wordBreak: 'break-all' }}>
              {selectedState.huso || 'America/Mexico_City'}
            </div>
          </div>
        </div>

        {/* Resumen geográfico */}
        {resumen && (
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5, background: 'rgba(9, 17, 38, 0.4)', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
            {resumen}
          </div>
        )}

        {/* Sección de arquitectura turística estructurada (Sección 6 y 19) */}
        <div className="tourism-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontSize: '0.74rem', fontWeight: 700, color: 'var(--text-main)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
              Patrimonio y Turismo
            </span>
            <Sparkles size={13} color="#00f0ff" />
          </div>

          <div className="tourism-tabs" role="tablist">
            <button
              type="button"
              className={`tourism-tab-btn ${activeTab === 'destinos' ? 'active' : ''}`}
              onClick={() => setActiveTab('destinos')}
              role="tab"
              aria-selected={activeTab === 'destinos'}
            >
              Destinos
            </button>
            <button
              type="button"
              className={`tourism-tab-btn ${activeTab === 'magicos' ? 'active' : ''}`}
              onClick={() => setActiveTab('magicos')}
              role="tab"
              aria-selected={activeTab === 'magicos'}
            >
              Pueblos Mágicos
            </button>
            <button
              type="button"
              className={`tourism-tab-btn ${activeTab === 'arqueologia' ? 'active' : ''}`}
              onClick={() => setActiveTab('arqueologia')}
              role="tab"
              aria-selected={activeTab === 'arqueologia'}
            >
              Historia
            </button>
            <button
              type="button"
              className={`tourism-tab-btn ${activeTab === 'gastronomia' ? 'active' : ''}`}
              onClick={() => setActiveTab('gastronomia')}
              role="tab"
              aria-selected={activeTab === 'gastronomia'}
            >
              Cocina
            </button>
          </div>

          <div className="tourism-tab-content">
            {activeTab === 'destinos' && (
              <div className="badge-tag-list">
                {tourism.destinos.map((item, idx) => (
                  <span key={idx} className="badge-tag accent">
                    <Navigation size={11} />
                    <span>{item}</span>
                  </span>
                ))}
                {tourism.playas && tourism.playas.length > 0 && (
                  tourism.playas.map((playa, idx) => (
                    <span key={`p-${idx}`} className="badge-tag">
                      <Waves size={11} color="#38bdf8" />
                      <span>{playa}</span>
                    </span>
                  ))
                )}
              </div>
            )}

            {activeTab === 'magicos' && (
              <div className="badge-tag-list">
                {tourism.pueblosMagicos && tourism.pueblosMagicos.length > 0 ? (
                  tourism.pueblosMagicos.map((pueblo, idx) => (
                    <span key={idx} className="badge-tag" style={{ borderColor: 'rgba(245, 158, 11, 0.3)', color: '#fbbf24' }}>
                      ★ {pueblo}
                    </span>
                  ))
                ) : (
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-dim)' }}>
                    Sin denominación de Pueblo Mágico registrada.
                  </span>
                )}
              </div>
            )}

            {activeTab === 'arqueologia' && (
              <div className="badge-tag-list">
                {tourism.arqueologia && tourism.arqueologia.length > 0 ? (
                  tourism.arqueologia.map((zona, idx) => (
                    <span key={idx} className="badge-tag">
                      <Landmark size={11} color="#a78bfa" />
                      <span>{zona}</span>
                    </span>
                  ))
                ) : (
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-dim)' }}>
                    Zonas arqueológicas en proceso de catalogación.
                  </span>
                )}
              </div>
            )}

            {activeTab === 'gastronomia' && (
              <div className="badge-tag-list">
                {tourism.gastronomia.map((platillo, idx) => (
                  <span key={idx} className="badge-tag">
                    <Utensils size={11} color="#f472b6" />
                    <span>{platillo}</span>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Estados colindantes con acceso rápido */}
        {neighborKeys.length > 0 && (
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px', fontWeight: 600 }}>
              Estados Colindantes
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
              {neighborKeys.map((cve) => {
                const nState = getEstadoByCve(cve);
                if (!nState) return null;
                return (
                  <button
                    key={cve}
                    type="button"
                    style={{
                      background: 'rgba(12, 24, 52, 0.7)',
                      border: '1px solid var(--border-subtle)',
                      borderRadius: '4px',
                      color: 'var(--text-muted)',
                      fontSize: '0.72rem',
                      padding: '3px 8px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onClick={() => onSelectState(nState)}
                    title={`Ver ${nState.nombreCorto}`}
                  >
                    {nState.nombreCorto}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Botón Explorar Estado / Municipios (Sección 12 y 18) */}
        <button
          type="button"
          className="explore-action-btn"
          onClick={() => onExploreState(selectedState)}
        >
          <span>Explorar estado</span>
          <ArrowRight size={17} />
        </button>
      </div>
    </aside>
  );
}
