import React from 'react';
import { Layers, Info } from 'lucide-react';

export default function Legend({ activeLayer = 'politica' }) {
  return (
    <div className="atlas-legend-hud" role="region" aria-label="Leyenda de navegación cartográfica">
      <div className="legend-title">
        <Layers size={13} />
        <span>Navegación / Leyenda</span>
      </div>

      <ul className="legend-list">
        <li className="legend-item">
          <span className="legend-swatch" style={{ background: '#132247', border: '1px solid #1d3368' }}></span>
          <span>División estatal (32 entidades)</span>
        </li>
        <li className="legend-item">
          <span className="legend-swatch" style={{ background: '#1d4ed8', border: '1px solid #00f0ff' }}></span>
          <span>Estado enfocado (hover)</span>
        </li>
        <li className="legend-item">
          <span className="legend-swatch" style={{ background: '#0369a1', border: '1px solid #00f0ff', boxShadow: '0 0 6px #00f0ff' }}></span>
          <span>Estado seleccionado</span>
        </li>
        <li className="legend-item" style={{ marginTop: '4px', opacity: 0.75, fontSize: '0.7rem' }}>
          <Info size={11} style={{ flexShrink: 0 }} />
          <span>Relieve topográfico y municipios listos para ampliación</span>
        </li>
      </ul>
    </div>
  );
}
