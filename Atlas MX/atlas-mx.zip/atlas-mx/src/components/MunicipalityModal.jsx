import React, { useState } from 'react';
import { X, MapPin, Compass, AlertCircle } from 'lucide-react';
import { MapaMunicipios } from '@webrek/mx-geo/municipios';
import { formatNumber } from '../utils/map';

export default function MunicipalityModal({ state, isOpen, onClose }) {
  const [selectedMun, setSelectedMun] = useState(null);

  if (!isOpen || !state) return null;

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="modal-title">
              {state.nombre} — Municipios
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '2px' }}>
              División municipal georreferenciada INEGI (Clave entidad: {state.cve})
            </div>
          </div>
          <button
            type="button"
            className="modal-close-btn"
            onClick={onClose}
            aria-label="Cerrar modal de municipios"
          >
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          <div className="municipios-map-wrapper">
            <MapaMunicipios
              estado={state.cve}
              zoom={true}
              paleta="azul"
              emptyColor="#0c1736"
              stroke="#1e3a8a"
              etiquetas="nombre"
              colorEtiqueta="#93c5fd"
              onSelect={(mun) => setSelectedMun(mun)}
            />
          </div>

          <div style={{
            padding: '12px 16px',
            background: 'rgba(10, 20, 44, 0.7)',
            border: '1px solid var(--border-glass)',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div>
              <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Municipio seleccionado
              </span>
              <div style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-pure)' }}>
                {selectedMun ? selectedMun.nombre : 'Haz clic en un municipio para seleccionarlo'}
              </div>
            </div>

            {selectedMun && (
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: 'var(--cyan-core)', background: 'rgba(0, 240, 255, 0.12)', padding: '4px 8px', borderRadius: '6px' }}>
                CVEGEO: {selectedMun.cvegeo}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
