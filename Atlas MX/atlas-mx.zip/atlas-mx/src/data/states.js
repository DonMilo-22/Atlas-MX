/**
 * Atlas MX — Información turística y cultural complementaria por entidad federativa.
 * Estructura extensible diseñada para escalar a fichas turísticas detalladas,
 * destinos, pueblos mágicos, zonas arqueológicas, playas y gastronomía.
 */

export const TOURISM_DATA = {
  "01": {
    lema: "Tierra de la Gente Buena",
    resumen: "Conocido por su tradición ferrocarrilera, vinícola y la icónica Feria Nacional de San Marcos.",
    turismo: {
      destinos: ["Centro Histórico de Aguascalientes", "Barrio de San Marcos", "Complejo Ferrocarrilero Tres Centurias"],
      pueblosMagicos: ["Real de Asientos", "Calvillo", "San José de Gracia"],
      arqueologia: ["El Ocote"],
      playas: [],
      gastronomia: ["Chile Aguascalentense", "Birria de carnero", "Gorditas de maíz"],
      clima: "Semiseco templado (18°C promedio)"
    }
  },
  "02": {
    lema: "Tierra de Oportunidades",
    resumen: "Puerta de entrada del noroeste, hogar de los valles vinícolas más afamados y las costas del Pacífico.",
    turismo: {
      destinos: ["Valle de Guadalupe", "La Bufadora en Ensenada", "Tijuana Cultural y Gastronómica"],
      pueblosMagicos: ["Tecate"],
      arqueologia: ["Pinturas Rupestres de Cataviña"],
      playas: ["Rosarito", "Bahía de los Ángeles", "San Felipe"],
      gastronomia: ["Tacos de pescado estilo Ensenada", "Vinos del Valle de Guadalupe", "Ensalada Caesar"],
      clima: "Mediterráneo y árido costero"
    }
  },
  "03": {
    lema: "Donde el desierto abraza al mar",
    resumen: "El acuario del mundo según Jacques Cousteau, santuario de la ballena gris y playas vírgenes.",
    turismo: {
      destinos: ["Arco de Cabo San Lucas", "Bahía Balandra", "Reserva de la Biósfera El Vizcaíno"],
      pueblosMagicos: ["Todos Santos", "Loreto", "Santa Rosalía"],
      arqueologia: ["Pinturas Rupestres de la Sierra de San Francisco"],
      playas: ["Playa Balandra", "Playa del Amor", "Bahía Concepción"],
      gastronomia: ["Almejas chocolatadas", "Tacos de mariscos", "Machaca de res"],
      clima: "Seco desértico cálido"
    }
  },
  "04": {
    lema: "Baluarte y Selva Maya",
    resumen: "Ciudad amurallada colonial declarada Patrimonio de la Humanidad y reserva de la selva de Calakmul.",
    turismo: {
      destinos: ["Murallas y Fuertes de San José y San Miguel", "Malecón de Campeche", "Isla Aguada"],
      pueblosMagicos: ["Palizada", "Isla Aguada", "Candelaria"],
      arqueologia: ["Calakmul", "Edzná", "Becán", "Balamkú"],
      playas: ["Playa Bonita", "Seybaplaya"],
      gastronomia: ["Pan de cazón", "Camarones al coco", "Pámpano empapelado"],
      clima: "Cálido subhúmedo tropical"
    }
  },
  "05": {
    lema: "Tierra de Dunas y Dinosaurios",
    resumen: "Cuna de la Revolución, oasis únicos en Cuatro Ciénegas y la mayor riqueza paleontológica del país.",
    turismo: {
      destinos: ["Museo del Desierto en Saltillo", "Dunas de Yeso", "Zona paleontológica Rincón Colorado"],
      pueblosMagicos: ["Cuatro Ciénegas", "Parras de la Fuente", "Arteaga", "Viesca", "Candela", "Guerrero", "General Cepeda"],
      arqueologia: ["Petrograbados de Narigua"],
      playas: [],
      gastronomia: ["Corte de carne asada", "Pan de pulque", "Vinos de Parras"],
      clima: "Seco y semiseco extremo"
    }
  },
  "06": {
    lema: "Tierra de Palmeras y Volcanes",
    resumen: "Pequeño en territorio pero inmenso en contrastes: desde el imponente Volcán de Fuego hasta las olas de Manzanillo.",
    turismo: {
      destinos: ["Volcán de Colima", "Bahía de Santiago", "Laguna de Cuyutlán"],
      pueblosMagicos: ["Comala"],
      arqueologia: ["La Campana", "El Chanal"],
      playas: ["Playa Miramar", "Cuyutlán (Ola Verde)", "Boca de Pascuales"],
      gastronomia: ["Sopitos colimenses", "Ceviche estilo Colima", "Tuba con cacahuate"],
      clima: "Cálido subhúmedo y semicálido"
    }
  },
  "07": {
    lema: "El Espíritu del Mundo Maya",
    resumen: "Uno de los estados con mayor biodiversidad y riqueza indígena, con cañones espectaculares y selvas milenarias.",
    turismo: {
      destinos: ["Cañón del Sumidero", "Cascadas de Agua Azul", "Lagos de Montebello"],
      pueblosMagicos: ["San Cristóbal de las Casas", "Chiapa de Corzo", "Palenque", "Comitán de Domínguez", "Copainalá", "Ocozocoautla"],
      arqueologia: ["Palenque", "Yaxchilán", "Bonampak", "Toniná"],
      playas: ["Puerto Arista", "Boca del Cielo"],
      gastronomia: ["Tamal de chipilín", "Cochito horneado", "Café de altura", "Pozol"],
      clima: "Tropical húmedo y templado en los altos"
    }
  },
  "08": {
    lema: "El Estado Grande",
    resumen: "Vasto territorio de montañas y cañones más profundos que el Gran Cañón del Colorado, hogar de los Rarámuris.",
    turismo: {
      destinos: ["Barrancas del Cobre y Ferrocarril Chepe", "Dunas de Samalayuca", "Cascada de Basaseachi"],
      pueblosMagicos: ["Creel", "Batopilas", "Casas Grandes", "Guachochi", "Hidalgo del Parral"],
      arqueologia: ["Paquimé (Patrimonio Mundial)", "Cueva de las Ventanas"],
      playas: [],
      gastronomia: ["Burritos de deshebrada", "Carne seca", "Queso menonita", "Manzanas de Cuauhtémoc"],
      clima: "Desértico en llanos y frío de montaña en sierra"
    }
  },
  "09": {
    lema: "El Corazón de la República",
    resumen: "Capital histórica y cosmopolita de México, construida sobre la mítica Tenochtitlan, con más de 170 museos.",
    turismo: {
      destinos: ["Zócalo y Centro Histórico", "Bosque y Castillo de Chapultepec", "Canales de Xochimilco", "Coyoacán"],
      pueblosMagicos: ["Barrios Mágicos: San Ángel, Coyoacán, Santa María la Ribera"],
      arqueologia: ["Templo Mayor", "Tlatelolco", "Cuicuilco"],
      playas: [],
      gastronomia: ["Tacos al pastor", "Tacos de suadero", "Guajolotas", "Churros"],
      clima: "Templado subhúmedo de valle (16°C)"
    }
  },
  "10": {
    lema: "Tierra del Cine y la Sierra",
    resumen: "Escenario de legendarias películas del Viejo Oeste y poseedor de espectaculares formaciones de la Sierra Madre Occidental.",
    turismo: {
      destinos: ["Paseo del Viejo Oeste", "Parque Natural Mexiquillo", "Centro Histórico barroco de Durango"],
      pueblosMagicos: ["Mapimí", "Nombre de Dios"],
      arqueologia: ["La Ferrería"],
      playas: [],
      gastronomia: ["Caldillo duranguense", "Gorditas de harina", "Queso de canasta"],
      clima: "Templado semiseco y frío en sierras"
    }
  },
  "11": {
    lema: "Cuna de la Independencia Nacional",
    resumen: "Corazón colonial con callejones románticos, festivales culturales de clase mundial y arquitectura virreinal.",
    turismo: {
      destinos: ["Callejón del Beso y Teatro Juárez en Guanajuato", "San Miguel de Allende", "Parroquia de Dolores Hidalgo"],
      pueblosMagicos: ["Dolores Hidalgo", "Mineral de Pozos", "Jalpa de Cánovas", "Salvatierra", "Yuriria", "Comonfort"],
      arqueologia: ["Plazuelas", "Peralta", "Cañada de la Virgen"],
      playas: [],
      gastronomia: ["Enchiladas mineras", "Cajeta de Celaya", "Guacamayas de León"],
      clima: "Templado subhúmedo"
    }
  },
  "12": {
    lema: "Sol, Tradición y Montaña",
    resumen: "Hogar de la legendaria bahía de Acapulco, la platería colonial de Taxco y las playas doradas de Zihuatanejo.",
    turismo: {
      destinos: ["La Quebrada en Acapulco", "Centro histórico y platerías de Taxco", "Bahías de Zihuatanejo"],
      pueblosMagicos: ["Taxco de Alarcón", "Ixtapa Zihuatanejo"],
      arqueologia: ["Tehuacalco", "La Organera-Xochipala", "Palma Sola"],
      playas: ["Playa Condesa", "Pie de la Cuesta", "Playa La Ropa", "Troncones"],
      gastronomia: ["Pozole verde guerrerense", "Pescado a la talla", "Mezcal guerrerense"],
      clima: "Cálido subhúmedo tropical"
    }
  },
  "13": {
    lema: "Tierra de Gigantes Toltecas",
    resumen: "Rico en aguas termales, paisajes mineros, los Atlantes de Tula y el espectacular corredor de la Huasteca hidalguense.",
    turismo: {
      destinos: ["Prismas Basálticos de Huasca", "Corredor de Balnearios de Ixmiquilpan", "Grutas de Tolantongo"],
      pueblosMagicos: ["Huasca de Ocampo", "Real del Monte", "Mineral del Chico", "Zimapán", "Huasca", "Acaxochitlán", "Metztitlán"],
      arqueologia: ["Tula (Atlantes de Tula)", "Huapalcalco"],
      playas: [],
      gastronomia: ["Pastes tradicionales", "Barbacoa en hoyo de maguey", "Zacahuil", "Ximbó"],
      clima: "Templado semiseco y de sierra"
    }
  },
  "14": {
    lema: "Tierra del Tequila y el Mariachi",
    resumen: "Símbolo de la identidad mexicana en el mundo, cuna del mariachi, charrería, agave azul y la perla tapatía.",
    turismo: {
      destinos: ["Centro Histórico de Guadalajara", "Campos agaveros de Tequila", "Malecón de Puerto Vallarta", "Lago de Chapala"],
      pueblosMagicos: ["Tequila", "Mazamitla", "Tapalpa", "San Sebastián del Oeste", "Lagos de Moreno", "Talpa de Allende", "Mascota", "Ajijic"],
      arqueologia: ["Guachimontones (pirámides circulares)"],
      playas: ["Playa Los Muertos", "Yelapa", "Mismaloya", "Costalegre"],
      gastronomia: ["Torta ahogada", "Birria tapatía", "Carne en su jugo", "Tequila artesanal"],
      clima: "Semicálido y templado"
    }
  },
  "15": {
    lema: "Encuentro de Culturas y Naturaleza",
    resumen: "Rodea el valle central con majestuosos volcanes nevados, santuarios de la mariposa monarca y grandes centros prehispánicos.",
    turismo: {
      destinos: ["Volcán Nevado de Toluca", "Lago de Valle de Bravo", "Santuarios de la Mariposa Monarca"],
      pueblosMagicos: ["Valle de Bravo", "Malinalco", "Tepotzotlán", "Ixtapan de la Sal", "El Oro", "Metepec", "Aculco", "Tonatico"],
      arqueologia: ["Teotihuacán (Pirámides del Sol y la Luna)", "Malinalco", "Tenayuca", "Calixtlahuaca"],
      playas: [],
      gastronomia: ["Chorizo verde de Toluca", "Mixiotes", "Trucha empapelada"],
      clima: "Templado semifrío de alta montaña"
    }
  },
  "16": {
    lema: "El Alma de México",
    resumen: "Celebración mística del Día de Muertos en Janitzio, pueblos alfareros de herencia purépecha y naturaleza virgen.",
    turismo: {
      destinos: ["Lago de Pátzcuaro y Janitzio", "Centro de cantera rosa de Morelia", "Parque Nacional Uruapan"],
      pueblosMagicos: ["Pátzcuaro", "Tlalpujahua", "Cuitzeo", "Santa Clara del Cobre", "Angangueo", "Tacámbaro", "Tzintzuntzan", "Jiquilpan", "Cotija"],
      arqueologia: ["Tzintzuntzan (Yácatas purépechas)", "Ihuatzio"],
      playas: ["Maruata", "Playa Azul", "Caleta de Campos"],
      gastronomia: ["Carnitas michoacanas", "Uchepos", "Corundas", "Sopa tarasca"],
      clima: "Templado y tropical en costa"
    }
  },
  "17": {
    lema: "La Eterna Primavera",
    resumen: "Clima privilegiado todo el año, cuna del zapatismo, jardines botánicos exuberantes y haciendas virreinales.",
    turismo: {
      destinos: ["Palacio de Cortés y Jardín Borda en Cuernavaca", "Lago de Tequesquitengo", "Cerro del Tepozteco"],
      pueblosMagicos: ["Tepoztlán", "Tlayacapan", "Xochitepec", "Tlaltizapán"],
      arqueologia: ["Xochicalco", "Tepozteco", "Teopanzolco"],
      playas: [],
      gastronomia: ["Cecina de Yecapixtla", "Tacos acorazados", "Mole de pipián"],
      clima: "Cálido y semicálido agradable"
    }
  },
  "18": {
    lema: "Tierra de Huicholes y Olas",
    resumen: "Riqueza mística de las etnias Wixárika y Cora, unida a los 300 km de paraísos turísticos en la Riviera Nayarit.",
    turismo: {
      destinos: ["Riviera Nayarit", "Islas Marietas y Playa Escondida", "Bahía de Banderas"],
      pueblosMagicos: ["Sayulita", "Compostela", "Jala", "Mexcaltitán", "San Blas", "Ahuacatlán", "Amatlán de Cañas", "Ixtlán del Río"],
      arqueologia: ["Los Toriles en Ixtlán del Río"],
      playas: ["Sayulita", "Punta de Mita", "San Pancho", "Novillero"],
      gastronomia: ["Pescado zarandeado", "Tlaxtihuilli", "Pan de plátano"],
      clima: "Cálido subhúmedo costero"
    }
  },
  "19": {
    lema: "Tierra de Titanes y Montañas",
    resumen: "Motor industrial de vanguardia enmarcado por el Cerro de la Silla, cañones escarpados y senderismo de alta montaña.",
    turismo: {
      destinos: ["Parque Fundidora y Paseo Santa Lucía", "Cañón de Matacanes", "Parque Ecológico Chipinque"],
      pueblosMagicos: ["Santiago", "Linares", "Bustamante", "General Terán", "Zaragoza"],
      arqueologia: ["Boca de Potrerillos"],
      playas: [],
      gastronomia: ["Cabrito al pastor", "Machacado con huevo", "Glorias de Linares"],
      clima: "Seco y semiseco extremoso"
    }
  },
  "20": {
    lema: "Tierra de Magia, Textil y Tradición",
    resumen: "El estado con mayor diversidad cultural y lingüística de México, epicentro culinario y artístico de Mesoamérica.",
    turismo: {
      destinos: ["Centro Histórico y Andador Turístico de Oaxaca", "Árbol del Tule", "Hierve el Agua"],
      pueblosMagicos: ["Capulálpam de Méndez", "Huautla de Jiménez", "San Pablo Villa de Mitla", "San Pedro y San Pablo Teposcolula", "Mazunte"],
      arqueologia: ["Monte Albán", "Mitla", "Yagul", "Dainzú"],
      playas: ["Bahías de Huatulco", "Puerto Escondido (Zicatela)", "Zipolite", "Mazunte"],
      gastronomia: ["Los 7 Moles oaxaqueños", "Tlayudas con tasajo", "Quesillo", "Chapulines", "Mezcal de maguey espadín"],
      clima: "Templado en valles y tropical en costas"
    }
  },
  "21": {
    lema: "Relicario de América",
    resumen: "Fusión magistral del barroco novohispano y la tradición culinaria conventual, vigilada por el Popocatépetl.",
    turismo: {
      destinos: ["Catedral y Centro de Puebla", "Gran Pirámide de Cholula", "Africam Safari"],
      pueblosMagicos: ["Cuetzalan", "Zacatlán de las Manzanas", "Chignahuapan", "Cholula", "Pahuatlán", "Tlatlauquitepec", "Xicotepec", "Atlixco", "Huejotzingo", "Teziutlán"],
      arqueologia: ["Gran Pirámide de Cholula", "Cantona", "Yohualichan"],
      playas: [],
      gastronomia: ["Mole poblano", "Chiles en nogada", "Cemitas poblanas", "Dulces de Santa Clara"],
      clima: "Templado subhúmedo de valle"
    }
  },
  "22": {
    lema: "Cuna de Conspiraciones y Misiones",
    resumen: "Elegancia colonial en sus plazas, misiones franciscanas en la Reserva de la Sierra Gorda y región del queso y vino.",
    turismo: {
      destinos: ["Acueducto y Centro Histórico de Querétaro", "Peña de Bernal", "Misiones de la Sierra Gorda"],
      pueblosMagicos: ["Bernal", "Jalpan de Serra", "Cadereyta", "Tequisquiapan", "San Joaquín", "Amealco de Bonfil", "Pinal de Amoles"],
      arqueologia: ["El Cerrito (Pirámide de El Pueblito)", "Ranas", "Toluquilla"],
      playas: [],
      gastronomia: ["Enchiladas queretanas", "Gorditas de migajas", "Quesos artesanales y vino"],
      clima: "Semiseco templado"
    }
  },
  "23": {
    lema: "El Caribe Mexicano",
    resumen: "Destino turístico número uno del país: playas de arena blanca, mar turquesa, arrecifes y cenotes sagrados.",
    turismo: {
      destinos: ["Zona Hotelera de Cancún", "Quinta Avenida de Playa del Carmen", "Laguna de los Siete Colores en Bacalar", "Cozumel"],
      pueblosMagicos: ["Bacalar", "Isla Mujeres", "Tulum", "Cozumel"],
      arqueologia: ["Tulum frente al mar", "Cobá", "San Gervasio", "Kohunlich"],
      playas: ["Playa Delfines", "Playa Paraíso en Tulum", "Playa Norte en Isla Mujeres", "Holbox"],
      gastronomia: ["Cochinita pibil estilo peninsular", "Tikin Xic (pescado en achiote)", "Mariscos frescos"],
      clima: "Cálido subhúmedo tropical"
    }
  },
  "24": {
    lema: "Tierra de Huasteca y Cantera",
    resumen: "Unión de la serenidad minera del Altiplano con la deslumbrante exuberancia acuática y selvática de la Huasteca Potosina.",
    turismo: {
      destinos: ["Cascada de Tamul", "Sótano de las Golondrinas", "Centro Histórico de cantera rosa potosina"],
      pueblosMagicos: ["Real de Catorce", "Xilitla (Jardín Escultórico Edward James)", "Aquismón", "Santa María del Río", "Tierra Nueva", "Ciudad del Maíz"],
      arqueologia: ["Tamtoc", "Tamohi"],
      playas: [],
      gastronomia: ["Enchiladas potosinas", "Zacahuil huasteco", "Guiso borracho", "Campechanas"],
      clima: "Seco en altiplano y cálido húmedo en huasteca"
    }
  },
  "25": {
    lema: "Tierra Fértil entre Mar y Sierra",
    resumen: "El granero de México, poseedor de costas ricas en mariscos, la música de banda y la calidez del puerto de Mazatlán.",
    turismo: {
      destinos: ["Malecón y Centro Histórico de Mazatlán", "Bahía de Topolobampo", "Islas del Golfo de California"],
      pueblosMagicos: ["Cosalá", "El Fuerte", "Rosario", "Mocorito", "San Ignacio"],
      arqueologia: ["Las Labradas (petroglifos en la playa)"],
      playas: ["Olas Altas", "Playa Brujas", "Isla de la Piedra", "Playa Las Glorias"],
      gastronomia: ["Aguachile de camarón", "Chilorio", "Ceviche sinaloense", "Pescado zarandeado"],
      clima: "Cálido y semicálido seco"
    }
  },
  "26": {
    lema: "Tierra del Desierto y Mar Bermejo",
    resumen: "Vasto territorio desértico bañado por el Mar de Cortés, tierra de la cultura Yaqui y Seri y gastronomía de carne suprema.",
    turismo: {
      destinos: ["Reserva del Pinacate y Gran Desierto de Altar", "Bahía de San Carlos", "Puerto Peñasco"],
      pueblosMagicos: ["Álamos", "Magdalena de Kino", "San Carlos", "Ures"],
      arqueologia: ["Trincheras"],
      playas: ["Bahía San Carlos", "Playa Los Algodones", "Bahía de Kino"],
      gastronomia: ["Cortes de carne sonorense", "Coyotas de piloncillo", "Tacos de carne asada", "Bacanora"],
      clima: "Muy seco desértico y extremoso"
    }
  },
  "27": {
    lema: "Edén del Sureste",
    resumen: "El agua hecha tierra: atravesado por los ríos más caudalosos del país, selvas tropicales y cuna de la civilización Olmeca.",
    turismo: {
      destinos: ["Parque Museo La Venta", "Pantanos de Centla", "Ruta del Cacao y Chocolate en Comalcalco"],
      pueblosMagicos: ["Tapijulapa", "Frontera", "Teapa"],
      arqueologia: ["La Venta (Cabezas Olmecas)", "Comalcalco (pirámides de ladrillo)", "Moral-Reforma"],
      playas: ["Playa Miramar", "Puerto Ceiba"],
      gastronomia: ["Pejelagarto asado", "Pozol frío con cacao", "Plátano relleno", "Queso de poro"],
      clima: "Cálido húmedo con abundantes lluvias"
    }
  },
  "28": {
    lema: "Tierra de Huastecos y Playas del Golfo",
    resumen: "Frontera norte unida a la costa del Golfo de México, rica en música de huapango y la biósfera El Cielo.",
    turismo: {
      destinos: ["Reserva de la Biósfera El Cielo", "Centro Histórico y Laguna del Carpintero en Tampico", "Barra del Tordo"],
      pueblosMagicos: ["Mier", "Tula"],
      arqueologia: ["Balcón de Montezuma", "El Sabinito"],
      playas: ["Playa Miramar (Ciudad Madero)", "Playa Bagdad", "La Pesca"],
      gastronomia: ["Carne a la tampiqueña", "Jaibas rellenas", "Gorditas de horno"],
      clima: "Cálido subhúmedo y semicálido"
    }
  },
  "29": {
    lema: "Cuna de la Nación",
    resumen: "El estado más pequeño en superficie pero gigante en historia tlaxcalteca, haciendas pulqueras y tradiciones taurinas.",
    turismo: {
      destinos: ["Santuario de las Luciérnagas en Nanacamilpa", "Centro Histórico de Tlaxcala", "Haciendas Pulqueras"],
      pueblosMagicos: ["Huamantla", "Tlaxco", "Ixtenco"],
      arqueologia: ["Cacaxtla (murales prehispánicos)", "Xochitécatl", "Tecoaque"],
      playas: [],
      gastronomia: ["Mixiote de carnero", "Mole prieto", "Sopa de milpa", "Pulque curado"],
      clima: "Templado subhúmedo"
    }
  },
  "30": {
    lema: "La Puerta de México al Mundo",
    resumen: "Riqueza cultural prodigiosa: desde los sones jarochos hasta la vainilla de Papantla y el volcán Pico de Orizaba.",
    turismo: {
      destinos: ["Acuario y Malecón del Puerto de Veracruz", "Fortaleza de San Juan de Ulúa", "Cascada de Eyipantla en Los Tuxtlas"],
      pueblosMagicos: ["Orizaba", "Papantla (Voladores)", "Coatepec (Capital del Café)", "Xico", "Coscomatepec", "Zozocolco", "Córdoba", "Naolinco"],
      arqueologia: ["El Tajín (Pirámide de los Nichos)", "Cempoala", "Tres Zapotes", "San Lorenzo Tenochtitlán"],
      playas: ["Costa Esmeralda", "Boca del Río", "Chachalacas (dunas gigantes)"],
      gastronomia: ["Huachinango a la veracruzana", "Arroz a la tumbada", "Café de Coatepec", "Toritos de cacahuate"],
      clima: "Cálido húmedo en llanura y frío en alta montaña"
    }
  },
  "31": {
    lema: "Tierra de Cenotes y Ciudades Blancas",
    resumen: "La serenidad y seguridad de Mérida, los deslumbrantes templos mayas y el anillo sagrado de miles de cenotes de agua cristalina.",
    turismo: {
      destinos: ["Paseo de Montejo y Centro de Mérida", "Cenotes de Cuzamá y Homún", "Ría Celestún y flamencos rosas"],
      pueblosMagicos: ["Izamal (La Ciudad Amarilla)", "Valladolid", "Maní", "Sisal", "Espita", "Motul", "Tekax"],
      arqueologia: ["Chichén Itzá (Maravilla del Mundo)", "Uxmal", "Mayapán", "Ek Balam", "Kabah", "Labná"],
      playas: ["Progreso (el muelle más largo)", "Sisal", "Celestún", "Las Coloradas"],
      gastronomia: ["Cochinita pibil auténtica", "Sopa de lima", "Panuchos y salbutes", "Papadzules", "Marquesitas"],
      clima: "Cálido subhúmedo tropical"
    }
  },
  "32": {
    lema: "Tierra de Plata y Rostro de Cantera",
    resumen: "Joya arquitectónica virreinal patrimonio mundial, con impresionantes museos de arte, minas coloniales y el teleférico.",
    turismo: {
      destinos: ["Centro Histórico de Zacatecas y Catedral", "Mina El Edén y Cerro de la Bufa", "Museo Rafael Coronel (máscaras)"],
      pueblosMagicos: ["Jerez de García Salinas", "Sombrerete", "Pinos", "Nochistlán", "Guadalupe", "Teúl de González Ortega", "Villanueva"],
      arqueologia: ["La Quemada", "Chalchihuites (Alta Vista)"],
      playas: [],
      gastronomia: ["Asado de boda", "Enchiladas zacatecanas", "Gorditas de canasta", "Mezcal zacatecano"],
      clima: "Semiseco templado"
    }
  }
};
